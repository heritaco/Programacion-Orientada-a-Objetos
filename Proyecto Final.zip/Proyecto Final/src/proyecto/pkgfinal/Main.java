package proyecto.pkgfinal;

public class Main {
    public static void main(String[] args) {
        Ejecucion ejecucion = new Ejecucion();
        ejecucion.iniciarPograma();
    }
}

Deberán programar un microratón, pueden trabajar en equipos de hasta 2 personas:

La clase se debe llamar "Raton", un objeto de tipo Raton debe aceptar como argumento de entrada un arreglo de caracteres de dos dimensiones, que representa un laberinto.

Como output se espera un arreglo de Strings, donde venga una secuencia de movimientos, los cuales pueden ser los siguientes: "arriba", "abajo", "derecha", "izquierda".

El laberinto tedrá 4 tipos de caracteres:

0 es un espacio vacío donde puede circular el ratón

1 es una pared

S es el cuadro donde inicia el ratón

F es el cuadro(s) que tiene la meta

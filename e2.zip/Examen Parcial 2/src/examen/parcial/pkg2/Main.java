package examen.parcial.pkg2;

public class Main {
    public static void main(String[] args) {
        Ejecucion ejecucion = new Ejecucion();
        ejecucion.iniciarPrograma();
    }

}

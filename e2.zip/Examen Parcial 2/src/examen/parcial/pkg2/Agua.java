package examen.parcial.pkg2;

public class Agua extends Pokemon {

    // Constructor
    public Agua(String nombre, String tipo, String[] ataques) {
        super(nombre, tipo, ataques);
    }

}

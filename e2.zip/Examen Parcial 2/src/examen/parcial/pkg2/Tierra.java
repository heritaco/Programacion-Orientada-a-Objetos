package examen.parcial.pkg2;

public class Tierra extends Pokemon {

    // Constructor
    public Tierra(String nombre, String tipo, String[] ataques) {
        super(nombre, tipo, ataques);
    }

}

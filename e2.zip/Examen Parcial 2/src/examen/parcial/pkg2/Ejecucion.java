package examen.parcial.pkg2;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Ejecucion {

    int pokemonesParaAdivinar = 15;
    public String[] pokemonesFuego = { "Charmander", "Cyndaquil", "Torchic", "Litten", "Fuecoco" };
    public String[] pokemonesAgua = { "Squirtle", "Totodile", "Mudkip", "Froakie", "Quaxly" };
    public String[] pokemonesTierra = { "Bulbasaur", "Chikorita", "Treecko", "Rowlet", "Sprigatito" };
    public String[] ataques = { "Hydro pump", "Solar Beam", "Eruption", "Flamethrower",
            "Aqua Jet", "Whirlpool", "Synthesis", "Petal Dance" };

    Pokemon[] pokemones = new Pokemon[pokemonesParaAdivinar];

    public Pokemon crearPokemones() {
        Random random = new Random();
        for (int i = 0; i < pokemonesParaAdivinar; i++) {
            int tipo = random.nextInt(3); // 0 = Agua, 1 = Fuego, 2 = Tierra
            String[] ataquesPokemon = new String[4];
            for (int j = 0; j < 4; j++) {
                ataquesPokemon[j] = ataques[random.nextInt(ataques.length)];
            }
            switch (tipo) {
                case 0:
                    pokemones[i] = new Agua(pokemonesAgua[random.nextInt(pokemonesAgua.length)],
                            "Agua",
                            ataquesPokemon);
                    break;
                case 1:
                    pokemones[i] = new Fuego(pokemonesFuego[random.nextInt(pokemonesFuego.length)],
                            "Fuego",
                            ataquesPokemon);
                    break;
                case 2:
                    pokemones[i] = new Tierra(pokemonesTierra[random.nextInt(pokemonesTierra.length)],
                            "Tierra",
                            ataquesPokemon);
                    break;
            }
        }
        return pokemones[random.nextInt(pokemonesParaAdivinar)];
    }

    public void iniciarPrograma() {
        Scanner sc = new Scanner(System.in);
        crearPokemones(); // Creamos pokemones
        Pokemon pokemonParaAdivinar = pokemones[new Random().nextInt(pokemones.length)]; // Seleccionamos un pokemon
                                                                                         // aleatorio para adivinar

        System.out.println("Bienvenido a adivina quien de pokemon!\n");

        mostrarPokemones();
        for (int intentos = 4; intentos > 0; intentos--) {
            System.out.println("Tienes " + intentos + " intentos para adivinar pokemon");
            System.out.println(
                    "Puedes preguntar por el tipo de pokemon o por sus ataques. Por ejemplo, puedes decir 'el tipo es fuego', 'el tipo es agua', ´el tipo es tierra´, 'el tipo es fuego', 'el ataque es Hydro pump', 'el ataque es Solar Beam', 'el ataque es Eruption', 'el ataque es Flamethrower', 'el ataque es Aqua Jet', 'el ataque es Whirlpool', 'el ataque es Synthesis', 'el ataque es Petal Dance'");
            String adivinar = sc.nextLine();

            if (adivinar.startsWith("el pokemon es ")) {
                if (adivinar.substring(14).equalsIgnoreCase(pokemonParaAdivinar.nombre)) {
                    System.out.println("¡Correcto! Has adivinado el pokemon. Es " + pokemonParaAdivinar.nombre + ".");
                    System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    System.out.println("¡Felicidades! Has adivinado el pokemon.");
                    System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    System.out.println("¡Felicidades! Has adivinado el pokemon.");
                    System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    System.out.println("¡Felicidades! Has adivinado el pokemon.");
                    return;
                } else {
                    System.out.println("No es correcto. El pokemon no es " + adivinar.substring(14) + ".");
                    pokemones = obtenerPokemonesNombreQueNoEs(adivinar.substring(14));
                    mostrarPokemones();
                }

            } else if (adivinar.startsWith("el tipo es ")) {
                if (adivinar.substring(11).equalsIgnoreCase(pokemonParaAdivinar.tipo)) {
                    System.out.println("¡Correcto! El tipo de pokemon es de " + pokemonParaAdivinar.tipo + ".");
                    pokemones = obtenerPokemonesPorTipo(pokemonParaAdivinar.tipo);
                    mostrarPokemones();
                } else {
                    System.out.println("No es correcto. El tipo de pokemon no es de " + adivinar.substring(11) + ".");
                    pokemones = obtenerPokemonesPorTipoDistinto(adivinar.substring(11));
                    mostrarPokemones();
                }

            } else if (adivinar.startsWith("el ataque es ")) {
                if (pokemonParaAdivinar.tieneAtaque(adivinar.substring(13))) {
                    System.out.println("¡Correcto! El pokemon tiene el ataque " + adivinar.substring(13) + ".");
                    pokemones = obtenerPokemonesPorAtaque(adivinar.substring(13));
                    mostrarPokemones();
                } else {
                    System.out.println("No es correcto. El pokemon no tiene el ataque " + adivinar.substring(13) + ".");
                    pokemones = obtenerPokemonesSinAtaque(adivinar.substring(13));
                    mostrarPokemones();
                }

            } else {
                System.out.print("Escribe bien. ");
            }
        }
        System.out.println("Has perdido. El pokemon era " + pokemonParaAdivinar.nombre + ".");
    }

    public Pokemon[] obtenerPokemonesNombreQueNoEs(String nombre) {
        ArrayList<Pokemon> pokemonesNombreQueNoEs = new ArrayList<>();
        for (Pokemon pokemon : pokemones) {
            if (!pokemon.nombre.equalsIgnoreCase(nombre)) {
                pokemonesNombreQueNoEs.add(pokemon);
            }
        }
        return pokemonesNombreQueNoEs.toArray(new Pokemon[0]);
    }

    public Pokemon[] obtenerPokemonesPorAtaque(String ataque) {
        ArrayList<Pokemon> pokemonesPorAtaque = new ArrayList<>();
        for (Pokemon pokemon : pokemones) {
            if (pokemon.tieneAtaque(ataque)) {
                pokemonesPorAtaque.add(pokemon);
            }
        }
        return pokemonesPorAtaque.toArray(new Pokemon[0]);
    }

    public Pokemon[] obtenerPokemonesSinAtaque(String ataque) {
        ArrayList<Pokemon> pokemonesSinAtaque = new ArrayList<>();
        for (Pokemon pokemon : pokemones) {
            if (!pokemon.tieneAtaque(ataque)) {
                pokemonesSinAtaque.add(pokemon);
            }
        }
        return pokemonesSinAtaque.toArray(new Pokemon[0]);
    }

    public Pokemon[] obtenerPokemonesPorTipo(String tipo) {
        ArrayList<Pokemon> pokemonesPorTipo = new ArrayList<>();
        for (Pokemon pokemon : pokemones) {
            if (pokemon.tipo.equalsIgnoreCase(tipo)) {
                pokemonesPorTipo.add(pokemon);
            }
        }
        return pokemonesPorTipo.toArray(new Pokemon[0]);
    }

    public Pokemon[] obtenerPokemonesPorTipoDistinto(String tipo) {
        ArrayList<Pokemon> pokemonesPorTipoDistinto = new ArrayList<>();
        for (Pokemon pokemon : pokemones) {
            if (!pokemon.tipo.equalsIgnoreCase(tipo)) {
                pokemonesPorTipoDistinto.add(pokemon);
            }
        }
        return pokemonesPorTipoDistinto.toArray(new Pokemon[0]);
    }

    public void mostrarPokemones() {
        System.out.println("Lista de pokemones:\n");
        int num = 1;
        for (Pokemon pokemon : pokemones) {
            System.out.println(num + ")");
            System.out.println("Nombre: " + pokemon.nombre);
            System.out.println("Tipo: " + pokemon.tipo);
            System.out.println("Ataques: ");
            for (String ataque : pokemon.ataques) {
                System.out.println(ataque);
            }
            System.out.println("--------------------");
            num++;
        }
    }

}
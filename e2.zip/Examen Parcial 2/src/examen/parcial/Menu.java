package examen.parcial;

public class Menu {
    public void mostrarMenu() {
        // Display the menu to the user
    }
}

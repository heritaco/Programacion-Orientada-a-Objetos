package examen.parcial.pkg2;

public class Fuego extends Pokemon {

    // Constructor
    public Fuego(String nombre, String tipo, String[] ataques) {
        super(nombre, tipo, ataques);
    }
}
